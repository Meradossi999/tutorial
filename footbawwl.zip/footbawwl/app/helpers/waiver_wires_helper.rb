module WaiverWiresHelper
  include PlayerNameModule
end
