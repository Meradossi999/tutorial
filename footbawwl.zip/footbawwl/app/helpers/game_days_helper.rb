module GameDaysHelper
end
