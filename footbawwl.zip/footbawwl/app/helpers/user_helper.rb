# -*- encoding : utf-8 -*-
module UserHelper
  include PlayerNameModule
end
