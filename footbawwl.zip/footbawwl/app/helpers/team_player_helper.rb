# -*- encoding : utf-8 -*-
module TeamPlayerHelper
end
