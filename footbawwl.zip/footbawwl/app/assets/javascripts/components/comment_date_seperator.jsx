var CommentDateSeparator = React.createClass({
  render: function() {
    return (
      <div id='date'>
        <h5>{this.props.date}</h5>
      </div>
    );
  }
});
