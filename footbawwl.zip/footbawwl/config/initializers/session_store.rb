# -*- encoding : utf-8 -*-
# Be sure to restart your server when you modify this file.

Footbawwl::Application.config.session_store :cookie_store, key: '_footbawwl_session'
