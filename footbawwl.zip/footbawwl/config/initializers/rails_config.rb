# -*- encoding : utf-8 -*-
RailsConfig.setup do |config|
  config.const_name = "Settings"
end
