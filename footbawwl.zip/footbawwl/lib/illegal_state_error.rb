# -*- encoding : utf-8 -*-
# Used for when data is in a squiffy state
class IllegalStateError < StandardError
end
