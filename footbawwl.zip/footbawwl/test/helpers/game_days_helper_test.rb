require 'test_helper'

class GameDaysHelperTest < ActionView::TestCase
end
