require 'test_helper'

class WaiverWiresHelperTest < ActionView::TestCase
end
