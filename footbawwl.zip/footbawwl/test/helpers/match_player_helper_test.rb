# -*- encoding : utf-8 -*-
require 'test_helper'

class MatchPlayerHelperTest < ActionView::TestCase
end
