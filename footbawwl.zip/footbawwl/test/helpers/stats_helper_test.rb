require 'test_helper'

class StatsHelperTest < ActionView::TestCase
end
