# -*- encoding : utf-8 -*-
require 'test_helper'

class NflPlayerHelperTest < ActionView::TestCase
end
