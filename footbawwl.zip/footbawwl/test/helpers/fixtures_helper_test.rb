# -*- encoding : utf-8 -*-
require 'test_helper'

class FixturesHelperTest < ActionView::TestCase
end
