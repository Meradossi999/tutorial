require 'test_helper'

class FinalHelperTest < ActionView::TestCase
end
