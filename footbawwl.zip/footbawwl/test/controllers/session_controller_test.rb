# -*- encoding : utf-8 -*-
require 'test_helper'

class SessionControllerTest < ActionController::TestCase
  test 'should get new' do
    #
  end
end
